import 'dart:math';

import 'package:clock_app/constants/constants.dart';
import 'package:flutter/material.dart';

class MinuteHandPainter extends CustomPainter {
  final Paint minuteHandPaint;
  int minutes;
  int seconds;

  MinuteHandPainter({this.minutes, this.seconds})
      : minuteHandPaint = new Paint() {
    minuteHandPaint.color = MinuteData().minuteHandColor;
    minuteHandPaint.style = PaintingStyle.stroke;
    minuteHandPaint.strokeWidth = 6.0;
    minuteHandPaint.strokeCap = StrokeCap.round;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final radius = size.height / 2;
    canvas.save();
    canvas.translate(radius, radius);
    canvas.rotate(2 * pi * ((this.minutes + (this.seconds / 60)) / 60));
    Path path = new Path();
    path.moveTo(0.0, -radius * 0.65);
    path.lineTo(0.0, radius * 0.1);
    path.close();
    canvas.drawPath(path, minuteHandPaint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(MinuteHandPainter oldDelegate) {
    return true;
  }
}

import 'dart:math';

import 'package:clock_app/constants/constants.dart';
import 'package:flutter/material.dart';

class SecondHandPainter extends CustomPainter {
  final Paint secondHandPaint;
  final Paint secondHandPointsPaint;

  int seconds;
  SecondHandPainter({this.seconds})
      : secondHandPaint = new Paint(),
        secondHandPointsPaint = new Paint() {
    secondHandPaint.color = MinuteData().secondsHandColor;
    secondHandPaint.style = PaintingStyle.stroke;
    secondHandPaint.strokeWidth = 4.0;
    secondHandPaint.strokeCap = StrokeCap.round;
    secondHandPointsPaint.color = MinuteData().secondsHandColor;
    secondHandPointsPaint.style = PaintingStyle.fill;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final radius = size.height / 2;
    canvas.save();
    canvas.translate(radius, radius);
    canvas.rotate(2 * pi * this.seconds / 60);
    Path path1 = new Path();
    Path path2 = new Path();
    path1.moveTo(0.0, -radius*0.83);
    path1.lineTo(0.0, radius*0.1);
    path2.addOval(
        new Rect.fromCircle(radius: 6.0, center: new Offset(0.0, 0.0)));
    canvas.drawPath(path1, secondHandPaint);
    canvas.drawPath(path2, secondHandPointsPaint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(SecondHandPainter oldDelegate) {
    return this.seconds != oldDelegate.seconds;
  }
}

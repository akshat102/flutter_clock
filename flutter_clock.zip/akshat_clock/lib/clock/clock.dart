import 'dart:async';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'clock_dial_painter.dart';
import 'clock_hands.dart';

import '../constants/constants.dart';
import 'package:flutter/material.dart';
import 'clock_face.dart';

typedef TimeProducer = DateTime Function();

class Clock extends StatefulWidget {
  final Color circleColor;
  final Color shadowColor;
  final ClockText clockHourText;
  final ClockText clockMinuteText;
  final TimeProducer getCurrentTime;
  final Duration updateDuration;
  Clock(
      {this.circleColor = const Color(0xfffe1ecf7),
      this.shadowColor = const Color(0xffd9e2ed),
      this.clockHourText = ClockText.arabic,
      this.clockMinuteText = ClockText.roman,
      this.getCurrentTime = getSystemTime,
      this.updateDuration = const Duration(seconds: 1)});

  static DateTime getSystemTime() {
    return new DateTime.now();
  }

  @override
  State<StatefulWidget> createState() => _Clock();
}

class _Clock extends State<Clock> {
  Timer _timer;
  DateTime dateTime;
HoursData hoursData = HoursData();
MinuteData minuteData = MinuteData();
@override
  void initState() {
    super.initState();
    dateTime = new DateTime.now();
    this._timer = new Timer.periodic(widget.updateDuration, setTime);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeRight,
      DeviceOrientation.landscapeLeft,
    ]);
  }

  void setTime(Timer timer) {
    setState(() {
      dateTime = new DateTime.now();
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
        children: <Widget>[
          Container(
        width: double.infinity,
        height: double.infinity,
        decoration: new BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.transparent,
          boxShadow: [
            new BoxShadow(
              offset: new Offset(0.0, 2.0),
              blurRadius: 0.0,
              color: widget.shadowColor,
            ),
            BoxShadow(
                offset: Offset(0.0, 8.0),
                color: widget.circleColor,//Colors.teal,//
                blurRadius: 10,
                spreadRadius: -8)
          ],
        ),
          ),
            Container(
              padding: EdgeInsets.all(12),
              width: double.infinity,
              height: double.infinity,
              child: new CustomPaint(
                painter: new ClockDialPainter(changedColor: Colors.black26,clockText: widget.clockHourText,romanNumeralList: minuteData.secondsList,hourTickMarkLength: 11.0,hourTickMarkWidth: 3.0,minuteTickMarkLength: 12.0,minuteTickMarkWidth: 3.0,textStyle: minuteData.textMinuteStyle),
              ),
            ),
            Stack(
              children: <Widget>[
                ClockFace(
                clockText: widget.clockHourText,
                dateTime: dateTime,
              ),
                Container(
                  padding: EdgeInsets.all(55),
                  width: double.infinity,
                  height: double.infinity,
                  child: new CustomPaint(
                    painter: new ClockDialPainter(changedColor:Color(0xff433D3F),clockText: widget.clockMinuteText,romanNumeralList: hoursData.hoursList,hourTickMarkLength: 15.0,hourTickMarkWidth: 4.0,minuteTickMarkLength: 3.0,minuteTickMarkWidth: 2.0,textStyle: hoursData.textHoursStyle),
                  ),
                ),
                Container(
                  alignment: Alignment.topCenter,
                  padding: EdgeInsets.symmetric(horizontal: 250, vertical: 110),
                  child: Text('${TimeOfDay.fromDateTime(DateTime.now()).format(context)}',
                  style: TextStyle(color: Color(0xffff0764),fontSize: 20,fontWeight: FontWeight.bold),),
                ),
                Container(
                  alignment: Alignment.bottomCenter,
                  padding: EdgeInsets.symmetric(horizontal: 245, vertical: 120),
                  child: TextField(
                    decoration: InputDecoration(
                      enabled: true,
                      fillColor: Color(0xffDCE8F6),//Color(0xff433D3F),//Color(0xffDCE8F6),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0.0,style: BorderStyle.none),
                      ),
                      hintText: '${DateFormat(' d MMM, EEE').format(DateTime.now())}',
                      hintStyle: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
                      filled: true
                    ),
                  ),
                )
            ]),
          ClockHand(dateTime: dateTime),
          ],
    );
  }
}

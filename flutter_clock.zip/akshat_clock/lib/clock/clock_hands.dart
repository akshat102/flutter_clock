import 'hands/hand_hour.dart';
import 'hands/hand_minute.dart';
import 'hands/hand_second.dart';
import 'package:flutter/material.dart';


class ClockHand extends StatelessWidget {
  final DateTime dateTime;
  final bool showHourHandleHeartShape;
  ClockHand({this.dateTime, this.showHourHandleHeartShape = false});

  @override
  Widget build(BuildContext context) {
    return  AspectRatio(
        aspectRatio: 1.0,
        child:  Container(
            width: double.infinity,
            child:  Stack(
                fit: StackFit.expand, 
                children: <Widget>[
                   CustomPaint(painter: HourHandPainter(
                      hours: dateTime.hour, minutes: dateTime.minute),
                  ),
                   CustomPaint(painter: MinuteHandPainter(
                      minutes: dateTime.minute, seconds: dateTime.second),
                  ),
                   CustomPaint(painter: SecondHandPainter(seconds: dateTime.second),
                  ),
                ]
            )
        )
    );
  }
}
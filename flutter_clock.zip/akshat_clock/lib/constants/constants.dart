import 'package:flutter/material.dart';

//roman gives roman numeral time
enum ClockText{
  roman,
  arabic
}

class HoursData{
  final hoursList = [ 'XII','I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];
  final TextStyle textHoursStyle= const TextStyle(color: Colors.black, fontFamily: 'Times New Roman', fontSize: 15.0);
  final Color hourHandColor = Color(0xff433D3F);
}


class MinuteData{
  final secondsList = [ '60','5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
  final TextStyle textMinuteStyle= const TextStyle(color: Colors.black, fontFamily: 'Times New Roman', fontSize: 10.0);
  final Color secondsHandColor = Color(0xffff0764);
  final Color minuteHandColor = Color(0xffc5cbdd);
}
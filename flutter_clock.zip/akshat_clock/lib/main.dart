import 'package:flutter/material.dart';
import 'clock/clock.dart';
void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Clock',
      home: SafeArea(
        child: Scaffold(
        backgroundColor: Colors.orange,
        body: Center(
          child: AspectRatio(
          aspectRatio: 5/3,
            child: Container(
        color: Colors.black26,
              child:Clock(),
      ),
        ),
    ),
      ),
      ),
    );
  }
}

